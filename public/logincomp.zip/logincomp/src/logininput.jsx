import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope } from '@fortawesome/free-solid-svg-icons';
import {faLock}from '@fortawesome/free-solid-svg-icons';
function InputWithIcon() {
  return (
    <>
      <div style={{ position: 'relative', display: 'block',marginBottom:"7px" }}>
        <div >Email</div>
        <div style={{ position: 'relative', display: 'inline-block' ,marginTop:"5px"}}>
          <FontAwesomeIcon icon={faEnvelope} style={{ position: 'absolute', left: '10px', top: '50%',marginRight:"7px", transform: 'translateY(-50%)' }} />
          <input

            type="text"
            placeholder="Enter your email"
            style={{ paddingLeft: '30px' }}
          /></div>
      </div>
      <div style={{ position: 'relative', display: 'block' }}>
        <div >Password</div>
        <div style={{ position: 'relative', display: 'inline-block',marginTop:"5px" }}>
          <FontAwesomeIcon icon={faLock} style={{ position: 'absolute', left: '10px', top: '50%',marginRight:"7px", transform: 'translateY(-50%)' }} />
          <input

            type="text"
            placeholder="Enter your password"
            style={{ paddingLeft: '30px' }}
          /></div>
      </div>
    </>
  );
};

export default InputWithIcon;
