import './LoginCard.css';
import InputWithIcon from './logininput.jsx';
import { FaGoogle,FaLinkedin,FaArrowLeft} from 'react-icons/fa'; 

function Card(){
    return(
        <div className="card">
            <button id="back"><p>&#60; -  Back</p></button>
            <h1>Welcome back !</h1>
            <InputWithIcon/>


            <div className="Forget"><a href="/home" className="Forget">Forget Password?</a></div>

            <button type="submit" id="loginmain">Login</button>

            <div className="otherbutton">
                
                <button type="submit" id="login"><FaGoogle style={{fontSize:"25px",marginRight:"15px"}}/><p>Login with Google</p></button>
                <button type="submit" id="login"><FaLinkedin style={{fontSize:"25px",marginRight:"15px"}}/><p>Login with Linkedin</p></button>
            </div>

            <div id="signup">Don't have an account ? <a href="/signup"> Sign Up</a></div>
        </div>
    );
}
export default Card;