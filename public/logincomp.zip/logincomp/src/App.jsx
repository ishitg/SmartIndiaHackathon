
import Card from './LoginCard.jsx'
function App() {
  return (
    <>
      <Card />
    </>
  );
}

export default App
